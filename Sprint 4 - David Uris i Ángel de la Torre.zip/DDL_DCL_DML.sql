--DDL
DROP TABLE RESERVA;
DROP TABLE HORARIS;
DROP TABLE VIATGE;
DROP TABLE USUARI;

CREATE TABLE USUARI (
    nom_usuari VARCHAR2(50) NOT NULL,
    contrasenya_hash VARCHAR2(128) NOT NULL,
    tipus VARCHAR2(20) CHECK (tipus IN ('Client', 'Administrador')) NOT NULL,
    nom_cognoms VARCHAR2(50),
    telefon VARCHAR2(12),
    correu VARCHAR2(50),
    PRIMARY KEY (nom_usuari)
);

CREATE TABLE VIATGE(
    id_viatge INT NOT NULL,
    titol VARCHAR2(50),
    descripcio VARCHAR2(500),
    preu FLOAT CHECK (preu >= 0),
    maxim_places NUMBER(2),
    durada FLOAT,
    tipus VARCHAR2(50),
    CONSTRAINT chk_tipus CHECK (tipus IN ('Públic', 'Privat')),
    PRIMARY KEY (id_viatge)
);

CREATE TABLE HORARIS(
    id_viatge INT NOT NULL REFERENCES VIATGE(id_viatge),
    hora TIMESTAMP,
    places_restants NUMBER(2) NOT NULL CHECK (places_restants >= 0),
    PRIMARY KEY (id_viatge, hora)
);

CREATE TABLE RESERVA (
    id_reserva INT NOT NULL,
    nom_usuari VARCHAR2(50) NOT NULL,
    id_viatge INT NOT NULL,                 
    hora TIMESTAMP NOT NULL,
    estat VARCHAR2(20) NOT NULL CHECK (estat IN ('Activa', 'Finalitzada', 'Cancelada')),
    data DATE NOT NULL,
    PRIMARY KEY (id_reserva),
    FOREIGN KEY (nom_usuari) REFERENCES USUARI(nom_usuari),
    FOREIGN KEY (id_viatge, hora) REFERENCES HORARIS(id_viatge, hora)
);

--DCL
CREATE USER admin
  IDENTIFIED BY admin
  DEFAULT TABLESPACE users
  TEMPORARY TABLESPACE temp
  PROFILE default 
  ACCOUNT UNLOCK;
  GRANT CONNECT TO admin;
  GRANT DBA TO admin;
  
GRANT SELECT, INSERT, UPDATE, DELETE ON RESERVA TO admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON VIATGE TO admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON USUARI TO admin;
GRANT SELECT, INSERT, UPDATE, DELETE ON HORARIS TO admin;

--DML
INSERT INTO USUARI (nom_usuari, contrasenya_hash, tipus, nom_cognoms, telefon, correu)
VALUES ('client', '5f4dcc3b5aa765d61d8327deb882cf99', 'Client', 'Juan Garcia', '000000000', 'client@exemple.com');
INSERT INTO USUARI (nom_usuari, contrasenya_hash, tipus, nom_cognoms, telefon, correu)
VALUES ('client2', 'ba3253876f5e7e3c8e4e7d77640c82d1', 'Client', 'Pedro López', '999999999', 'client2@exemple.com');
INSERT INTO USUARI (nom_usuari, contrasenya_hash, tipus, nom_cognoms, telefon, correu)
VALUES ('administrador', 'd8578edf8458ce06fbc5bb5a06295ce8703', 'Administrador', null, null, null);

INSERT INTO VIATGE (id_viatge, titol, descripcio, preu, maxim_places, durada, tipus)
VALUES (1, '1 Hour Sailing Tour', '1h Sailing Experience', 30.0, 9, 1, 'Públic');
INSERT INTO VIATGE (id_viatge, titol, descripcio, preu, maxim_places, durada, tipus)
VALUES (2, 'Private Sailing Tour (max. 9)', 'Private Sailing Tour (max. 9)', 200.0, 9, 1, 'Privat');

INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (1, TO_TIMESTAMP('2024-12-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (1, TO_TIMESTAMP('2024-12-10 12:30:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (1, TO_TIMESTAMP('2024-12-11 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (2, TO_TIMESTAMP('2024-12-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (2, TO_TIMESTAMP('2024-12-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 9);
INSERT INTO HORARIS (id_viatge, hora, places_restants)
VALUES (2, TO_TIMESTAMP('2024-12-10 10:00:00', 'YYYY-MM-DD HH24:MI:SS'), 9);

INSERT INTO RESERVA (id_reserva, nom_usuari, id_viatge, hora, estat, data)
VALUES (1, 'client', 1, TO_TIMESTAMP('2024-12-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Activa', TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO RESERVA (id_reserva, nom_usuari, id_viatge, hora, estat, data)
VALUES (2, 'client2', 1, TO_TIMESTAMP('2024-12-10 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'Activa', TO_DATE('2024-12-01', 'YYYY-MM-DD'));
INSERT INTO RESERVA (id_reserva, nom_usuari, id_viatge, hora, estat, data)
VALUES (3, 'client', 2, TO_TIMESTAMP('2024-12-10 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), 'Finalitzada', TO_DATE('2024-12-01', 'YYYY-MM-DD'));

BEGIN
    FOR r IN (SELECT id_viatge, hora, COUNT(*) AS reservas_existentes
              FROM RESERVA
              WHERE estat != 'Cancelada'
              GROUP BY id_viatge, hora) LOOP
        UPDATE HORARIS
        SET places_restants = (SELECT maxim_places FROM VIATGE WHERE id_viatge = r.id_viatge) - r.reservas_existentes
        WHERE id_viatge = r.id_viatge AND hora = r.hora;
    END LOOP;
END;
/
